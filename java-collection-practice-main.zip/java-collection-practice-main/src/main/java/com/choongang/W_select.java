package com.choongang;

import java.util.HashMap;

public class W_select {
    public HashMap<String, Integer> select(String[] arr, HashMap<String, Integer> hashMap) {
        // TODO:
        // arr의 요소를 key로 가지는 hashMap을 생성. 값은 기존 hashMap의 value

        HashMap<String, Integer> map = new HashMap<String, Integer>();

        int count = 0;
        for(int i = 0; i < arr.length; i++) {
            if(hashMap.containsKey(arr[i])) {
                map.put(arr[i], hashMap.get(arr[i]));
            }
        }
        return map;
    }
}
