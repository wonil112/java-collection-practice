package com.choongang;

import java.util.ArrayList;

public class H_removeFromNth {
    public String removeFromNth(ArrayList<String> arrayList, int index) {
        // TODO:

        String str;
        if(arrayList.size() < index) {
            return null;
        } else {
            str = arrayList.remove(index);
        }
        return str;

    }
}
