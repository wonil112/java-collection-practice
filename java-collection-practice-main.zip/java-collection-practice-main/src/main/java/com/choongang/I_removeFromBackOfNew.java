package com.choongang;

import java.util.ArrayList;

public class I_removeFromBackOfNew {
    public ArrayList<Integer> removeFromBackOfNew(ArrayList<Integer> arrayList) {
        // TODO:

        ArrayList<Integer> renewArrayList = new ArrayList<>();

        if(arrayList.isEmpty()) {
            return null;
        } else {
            for (int i = 0; i < arrayList.size(); i++) {
                renewArrayList.add(i, arrayList.get(i));
            }
        }
        renewArrayList.remove(arrayList.size() - 1);
        return renewArrayList;
    }
}
