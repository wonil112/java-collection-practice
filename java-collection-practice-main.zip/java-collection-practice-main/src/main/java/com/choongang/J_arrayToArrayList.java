package com.choongang;

import java.util.ArrayList;
import java.util.Arrays;

public class J_arrayToArrayList {
    public ArrayList<String> arrayToArrayList(String[] arr) {
        // TODO:

        ArrayList<String> arrayList = new ArrayList<>();
        if(arr.length == 0) {
            return null;
        } else {
            for(int i = 0; i < arr.length; i++) {
                arrayList.add(i, arr[i]);
            }
        } return arrayList;
    }
}
