package com.choongang;
import java.util.*;

public class B_getNthElement {
    public Integer getNthElement(ArrayList<Integer> arrayList, int index) {
        // TODO:

        if (arrayList.size() == 0) {
            return null;
        } else if (index >= arrayList.size()) {
            return null;
        } else {
            return arrayList.get(index);
        }
    }
}
