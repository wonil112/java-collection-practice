package com.choongang;

import java.util.HashMap;

public class M_getValue {
    public Integer getValue(HashMap<String, Integer> hashMap, String key) {
        // TODO:

        return hashMap.get(key);
    }
}
