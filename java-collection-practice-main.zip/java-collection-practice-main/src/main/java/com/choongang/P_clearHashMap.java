package com.choongang;

import java.util.HashMap;

public class P_clearHashMap {
    public void clearHashMap(HashMap<Integer, Boolean> hashMap) {
        // TODO:

        hashMap.clear();

    }
}
