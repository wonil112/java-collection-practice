package com.choongang;

import java.util.HashMap;

public class T_isContain {
    public boolean isContain(HashMap<String, Integer> hashMap, String key) {
        // TODO:
        // containsKey

        if(hashMap.containsKey(key)) {
            return true;
        } else {
            return false;
        }

    }
}
