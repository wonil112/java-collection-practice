package com.choongang;

import java.util.ArrayList;
import java.util.Iterator;

public class L_sumAllElements {
    public int sumAllElements(ArrayList<Integer> arrayList) {
        // TODO:

        int sum = 0;

        Iterator<Integer> list = arrayList.iterator();

        if(arrayList.isEmpty()) {
            return sum;
        } else {
            while(list.hasNext()) {
                sum += list.next();
            }
        }
            return sum;
    }
}
