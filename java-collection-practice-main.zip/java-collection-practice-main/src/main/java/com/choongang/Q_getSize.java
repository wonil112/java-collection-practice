package com.choongang;

import java.util.HashMap;

public class Q_getSize {
    public int getSize(HashMap<Integer, Integer> hashMap) {
        // TODO:

        return hashMap.size();
    }
}
