package com.choongang;

import java.util.HashMap;

public class O_removeEntry {
    public void removeEntry(HashMap<String, Integer> hashMap, String key) {
        // TODO:

        hashMap.remove(key);


    }
}
