package com.choongang;

import java.util.*;

public class U_getElementOfListEntry {
    public String getElementOfListEntry(HashMap<String, List<String>> hashMap, String key, int index) {
        // TODO:
        // 1. containsKey 로 key 존재여부 확인.
        // 2. 있다면 해당 value에 있는 list의 index 요소를 반환.
        // 3. index > list.size() => null
        // 4. else -> null

        if (hashMap.containsKey(key)) {
            List<String> str = hashMap.get(key);
            if (str.size() > index) {
                String result = str.get(index);
                return result;
            } else {
                return null;
            }
        } else {
            return null;
        }
    }
}
