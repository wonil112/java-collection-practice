package com.choongang;

import java.util.ArrayList;

public class G_removeFromFront {
    public Integer removeFromFront(ArrayList<Integer> arrayList) {
        // TODO:

        int num;
        if(arrayList.isEmpty()) {
            return null;
        } else {
           num = arrayList.remove(0);
        }
        return num;
    }
}
