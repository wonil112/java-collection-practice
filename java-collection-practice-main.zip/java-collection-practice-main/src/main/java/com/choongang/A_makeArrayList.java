package com.choongang;

import java.util.ArrayList;

public class A_makeArrayList {
    public ArrayList<Integer> makeArrayList() {
        // TODO:
        ArrayList<Integer> arrayList = new ArrayList<>();

        arrayList.add(1);
        arrayList.add(2);
        arrayList.add(3);
        arrayList.add(4);
        arrayList.add(5);

        return arrayList;
    }
}
