package com.choongang;

import java.util.ArrayList;

public class E_addNth {
    public ArrayList<Integer> addNth(ArrayList<Integer> arrayList, int index, int element) {
        // TODO:

        // index 위치에 element 를 추가하고 arrayList를 리턴
        // 입력받은 index 가 arrayList의 크기를 벗어나면 null 리턴

        if(arrayList.isEmpty()) {
            return null;
        } else if (arrayList.size() < index) {
            return null;
        } else {
            arrayList.add(index, element);
            return arrayList;
        }
    }
}
