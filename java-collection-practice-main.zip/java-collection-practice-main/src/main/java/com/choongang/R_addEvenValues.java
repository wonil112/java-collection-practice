package com.choongang;

import java.util.*;

public class R_addEvenValues {
    public int addEvenValues(HashMap<Character, Integer> hashMap) {
        // TODO:

        int result = 0;
        Set<Character> keySet = hashMap.keySet();
        Iterator<Character> keyIterator = keySet.iterator();
        while (keyIterator.hasNext()) {
            Character key = keyIterator.next();
            Integer value = hashMap.get(key);
            if(value % 2 == 0) {
                result += value;
            }
        }
        return result;
    }
}
