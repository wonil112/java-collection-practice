package com.choongang;

import com.sun.source.doctree.ParamTree;

import java.util.ArrayList;

public class C_getLastElement {
    public String getLastElement(ArrayList<String> arrayList) {
        // TODO:

        // arrayList의 마지막 요소를 리턴.
        // 빈 arrayList 라면 null 리턴
        String result = "";
        if (arrayList.isEmpty()) {
            return null;
        } else if (arrayList.size() > 0) {
            result = arrayList.get(arrayList.size() - 1);
        } return result;
    }
}