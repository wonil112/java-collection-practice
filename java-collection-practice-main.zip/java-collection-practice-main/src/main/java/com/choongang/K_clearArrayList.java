package com.choongang;

import java.util.ArrayList;
import java.util.Iterator;

public class K_clearArrayList {
    public ArrayList<Integer> clearArrayList(ArrayList<Integer> arrayList) {
        // TODO:

        arrayList.clear();
        return arrayList;
    }
}
