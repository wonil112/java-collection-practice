package com.choongang;

import java.util.HashMap;

public class N_addKeyAndValue {
    public HashMap<String, Integer> addKeyAndValue(HashMap<String, Integer> hashMap, String key, int value) {
        // TODO:

        hashMap.put(key, value);
        return hashMap;

    }
}
