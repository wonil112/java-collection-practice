package com.choongang;

import java.util.HashMap;

public class X_countAllCharacter {
    public HashMap<Character, Integer> countAllCharacter(String str) {
        // TODO:
        // 문자열을 입력받아 각 문자를 키로 갖는 hashMap 리턴
        // 각 key의 value는 문자열에서 각 문자의 등장횟수.
        // for loop을 돌면서 str의 문자 종류와 개수를

        HashMap<Character, Integer> hashMap = new HashMap<>();

        if (str.length() == 0) {
            return null;
        } else {
            for (int i = 0; i < str.length(); i++) {
                if (!hashMap.containsKey(str.charAt(i))) {
                    hashMap.put(str.charAt(i), 1);
                } else {
                    hashMap.put(str.charAt(i), hashMap.get(str.charAt(i)) + 1);
                }
            }
        }
        return hashMap;
    }
}
