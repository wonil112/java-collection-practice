package com.choongang;

import java.util.ArrayList;

public class D_addLast {
    public ArrayList<String> addLast(ArrayList<String> arrayList, String str) {
        // TODO:

        // 문자열을 입력받아 arrayList 맨 뒤에 요소를 추가 후 arrayList를 리턴

        arrayList.add(str);

        return arrayList;
    }
}
