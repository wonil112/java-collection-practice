package com.choongang;

import java.util.HashMap;

public class V_isMember {
    public boolean isMember(HashMap<String, String> member, String username, String password) {
        // TODO:
        // 입력받은 username과 password가 hashmap 안에 있는 값과 일치하는지 여부를 리턴


        if(member.containsKey(username)) {
            if(member.get(username) == password) {
                return true;
            } else {
                return false;
            }
        } return false;
    }
}
