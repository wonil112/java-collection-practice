package com.choongang;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class S_addFullNameEntry {
    public HashMap<String, String> addFullNameEntry(HashMap<String, String> hashMap) {

        String fullName = "";

        Set<String> keySet = hashMap.keySet();
        Iterator<String> keySetIterator = keySet.iterator();
        if (keySetIterator.hasNext()) {
            if (keySetIterator.next() == "firstName") {
                fullName = hashMap.get("firstName");
                keySetIterator.hasNext();
                fullName = fullName + hashMap.get("lastName");
            } else {
                fullName = hashMap.get("lastName");
                keySetIterator.hasNext();
                fullName = hashMap.get("firstName") + fullName;
            }
        }
        hashMap.put("fullName", fullName);
        return hashMap;
    }
}